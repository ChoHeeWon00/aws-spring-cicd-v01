<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page session="false" %>
<html>
<head>
	<title>Home</title>
</head>
<body>
	<h1>
		my ci/cd project
	</h1>
	<h5> ${getLocalAddr}. </h5>
</body>
</html>
