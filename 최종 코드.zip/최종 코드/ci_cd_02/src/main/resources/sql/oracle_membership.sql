create table aws_membership(
	id varchar2(20) primary key,
	pwd varchar2(100) not null,
	name varchar2(100) not null,
	addr varchar2(200) not null,
	img_file_name varchar2(200) default 'nan'
);

CREATE TABLE aws_membership (
    id VARCHAR(20) PRIMARY KEY,
    pwd VARCHAR(100) NOT NULL,
    name VARCHAR(100) NOT NULL,
    addr VARCHAR(200) NOT NULL,
    img_file_name VARCHAR(200) DEFAULT 'nan'
);
