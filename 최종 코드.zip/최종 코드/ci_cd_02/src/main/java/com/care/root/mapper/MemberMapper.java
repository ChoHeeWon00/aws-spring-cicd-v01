package com.care.root.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.care.root.dto.MemberDTO;


public interface MemberMapper {
	public MemberDTO getMember(String id);
	public ArrayList<MemberDTO> getList();
	public ArrayList<MemberDTO> getData(@Param("bbb") String id);
	public int register( MemberDTO dto );
	public void delete( String id );
}









