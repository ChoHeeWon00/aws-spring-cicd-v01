package com.care.root.service;
import java.io.File;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.care.root.config.FilePath;
import com.care.root.dto.MemberDTO;
import com.care.root.mapper.MemberMapper;
@Service
@PropertySource("classpath:properties/aws_s3.properties")
public class MemberServiceImpl implements MemberService{
	   @Value("${s3.bucket}")
	   private String bucket;
	   @Autowired
	   AmazonS3 amazonS3;
	
	@Autowired MemberMapper mapper;
	BCryptPasswordEncoder encoder;
	public MemberServiceImpl() {
		encoder = new BCryptPasswordEncoder();
	}
	public int loginCheck(String id, String pwd) {
		ArrayList<MemberDTO> list = mapper.getData(id);
		if( list.size() != 0 ) {
			MemberDTO dto = list.get(0);
			if(pwd.equals(dto.getPwd()) || 
					encoder.matches(pwd, dto.getPwd()) ) {
				return 1;
			}
		}
		return 0;
	}
	public ArrayList<MemberDTO> getList(){
		return mapper.getData( null );
	}
	public MemberDTO getMember(String id) {
		ArrayList<MemberDTO> list = mapper.getData(id);
		return list.get(0);
	}
	public int register( MemberDTO dto , MultipartFile imgFile) {
		String securePwd = encoder.encode(dto.getPwd());
		dto.setPwd(securePwd);
		if( imgFile == null ) {
			dto.setImgFileName( "nan" );
		}else {
			dto.setImgFileName( dto.getId()+"-"+imgFile.getOriginalFilename() );
		}
		int result = 0;
		try {
			result = mapper.register( dto );
			if( result == 1 ) {
				/*
				File file = new File(FilePath.IMAGE_REPO + "/" + dto.getImgFileName() );
				if(imgFile != null ) {
					imgFile.transferTo( file );
				}
				*/
				if(imgFile != null ) {
				ObjectMetadata metadata = new ObjectMetadata();
	              metadata.setContentType(imgFile.getContentType());//파일 유형 s3알려줌
	              metadata.setContentLength(imgFile.getSize());//파일 크기 s3알려줌
	              amazonS3.putObject(bucket, dto.getImgFileName(), imgFile.getInputStream(), metadata);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public void delete(String file,String id) {
		try {
			mapper.delete(id);
			amazonS3.deleteObject(bucket, file);
			/*
			File f = new File(FilePath.IMAGE_REPO + "/" + file);
			if( f.exists() ) {
				f.delete();
			}
			*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}











