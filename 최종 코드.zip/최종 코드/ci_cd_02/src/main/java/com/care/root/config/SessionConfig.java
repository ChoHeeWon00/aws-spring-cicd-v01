package com.care.root.config;

public interface SessionConfig {
	public static String LOGIN = "username";
}
