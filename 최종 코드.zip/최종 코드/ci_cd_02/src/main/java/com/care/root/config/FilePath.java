package com.care.root.config;

public interface FilePath {
	public static final String IMAGE_REPO = "C:/spring/image_repo";
}
