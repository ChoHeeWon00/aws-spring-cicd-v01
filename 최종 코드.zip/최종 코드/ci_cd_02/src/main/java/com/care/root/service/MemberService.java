package com.care.root.service;

import java.util.ArrayList;

import org.springframework.web.multipart.MultipartFile;

import com.care.root.dto.MemberDTO;


public interface MemberService {
	public int loginCheck(String id, String pwd);
	public ArrayList<MemberDTO>  getList();
	public MemberDTO getMember(String id);
	public int register( MemberDTO dto , MultipartFile imgFile );
	public void delete(String file,String id);
}









