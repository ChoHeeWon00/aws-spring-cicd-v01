   function readURL(input) {
	   var file = input.files[0] 
	   console.log(file)
      if (file != '') {
	      var reader = new FileReader();
	      reader.readAsDataURL(file); 
	      reader.onload = function (e) { 
	      document.getElementById("preview").src = e.target.result
       }
     }
  } 