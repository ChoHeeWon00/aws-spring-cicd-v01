<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<div style="width:500px; margin:0 auto;">
<%@ include file="/WEB-INF/views/default/header.jsp" %>
	<div>
		<div style="display: flex;">
			<div style="margin-right : 20px; ">
				<img src="${contextPath }/member/download?file=${member.imgFileName }" style="width:100px; height : 100px">
			</div>
			<div>
				id : ${member.id }<br>
				name : ${member.name}<br>
				우편번호 : ${ addr[0] }<br>
				주 소  : ${ addr[1] }<br>
				상세 주소 : ${ addr[2] }<br>
			</div>
		</div>
		<hr>
		<div align="center">
			<button onclick="location.href='${contextPath }/member/delete?file=${member.imgFileName }&id=${member.id }'">삭제</button>
		</div>
	</div>
</div>
</body>
</html>






