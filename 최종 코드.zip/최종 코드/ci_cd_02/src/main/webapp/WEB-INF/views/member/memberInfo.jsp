<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<div style="width:500px; margin:0 auto;">
	<%@ include file="/WEB-INF/views/default/header.jsp" %>
	<table border="1">
		<tr>
			<th>아이디</th> <th>이름</th> <th>주소</th> <th>이미지 이름</th>
		</tr>
		<c:forEach var="dto" items="${list }">
		<tr>
			<td>${dto.id }</td>
			<td>
				<a href="${contextPath }/member/info?id=${dto.id }">
					${dto.name }
				</a>
			</td>
			<td>${dto.addr }</td>
			<td>${dto.imgFileName }</td>
		</tr>
		</c:forEach>
	</table>
	</div>
</body>
</html>




