<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

 <div style="width:500px; margin:0 auto;">
<%@ include file="/WEB-INF/views/default/header.jsp" %>
	<h1>- SUCCESS -</h1>
	<h3>ip : ${ip }</h3>
	</div>
</body>
</html>





