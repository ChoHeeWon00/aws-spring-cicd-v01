package com.care.root.controller;

import java.io.File;
import java.io.FileInputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.care.root.config.FilePath;
import com.care.root.config.SessionConfig;
import com.care.root.dto.MemberDTO;
import com.care.root.service.MemberService;

@Controller
@RequestMapping("member")
public class MemberController implements SessionConfig{
	@Autowired MemberService ms;
	@GetMapping("login")
	public String loginForm(){
		return "/member/login";
	}
	@PostMapping("login")
	public String login( String id ) {
		return "forward:login_check";
	}
	@PostMapping("login_check")
	public String loginCheck(String id, String pwd,
							HttpSession session) {
		int result = ms.loginCheck(id, pwd);
		if(result == 1) {
			session.setAttribute( LOGIN, id );
			return "redirect:success";
		}
		return "redirect:login";
	}
	@GetMapping("success")
	public String successLogin() {
		return "member/successLogin";
	}
	@GetMapping("logout")
	public String logout(HttpSession session ) {
		if(session.getAttribute( LOGIN ) != null) {
			session.invalidate();
		}
		return "redirect:login";
	}
	@GetMapping("list")
	public String list(Model model) {
		model.addAttribute("list", ms.getList() );
		return "member/memberInfo";
	}
	@GetMapping("info")
	public String info(String id, Model model) {
		MemberDTO dto = ms.getMember(id);
		String [] addr = dto.getAddr().split(",");
		model.addAttribute("member", dto );
		model.addAttribute("addr",addr);
		return "member/info";
	}
	@GetMapping("reg_form")
	public String reg_form() {
		return "member/register";
	}

	@PostMapping("register")
	public String reg(MemberDTO dto,
				@RequestParam(value="imgName" , required = false) MultipartFile imgFile) {
		int result = ms.register( dto , imgFile  );
		if(result == 1) {
			return "redirect:login";
		}
		return "redirect:reg_form";
	}
	@GetMapping("download")
	public void download(String file, HttpServletResponse res) throws Exception {
		res.addHeader("Content-disposition", 
				"attachment; fileName=" + 
				URLEncoder.encode( file, "utf-8"));
		File f = new File(FilePath.IMAGE_REPO + "/" + file);
		if( f.exists() ) {
			FileInputStream in = new FileInputStream( f );
			FileCopyUtils.copy(in, res.getOutputStream() );
			in.close();
		}
	}
	@GetMapping("delete")
	public String delete(String file, String id, HttpSession session) {
		ms.delete(file, id);
		if(id.equals(session.getAttribute(LOGIN))) {
			session.invalidate();
		}
		return "redirect:/";
	}
}












