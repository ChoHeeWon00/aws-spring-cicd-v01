package com.care.root.service;
import java.io.File;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.care.root.config.FilePath;
import com.care.root.dto.MemberDTO;
import com.care.root.mapper.MemberMapper;
@Service
public class MemberServiceImpl implements MemberService{
	@Autowired MemberMapper mapper;
	BCryptPasswordEncoder encoder;
	public MemberServiceImpl() {
		encoder = new BCryptPasswordEncoder();
	}
	public int loginCheck(String id, String pwd) {
		ArrayList<MemberDTO> list = mapper.getData(id);
		if( list.size() != 0 ) {
			MemberDTO dto = list.get(0);
			if(pwd.equals(dto.getPwd()) || 
					encoder.matches(pwd, dto.getPwd()) ) {
				return 1;
			}
		}
		return 0;
	}
	public ArrayList<MemberDTO> getList(){
		return mapper.getData( null );
	}
	public MemberDTO getMember(String id) {
		ArrayList<MemberDTO> list = mapper.getData(id);
		return list.get(0);
	}
	public int register( MemberDTO dto , MultipartFile imgFile) {
		String securePwd = encoder.encode(dto.getPwd());
		dto.setPwd(securePwd);
		if( imgFile == null ) {
			dto.setImgFileName( "nan" );
		}else {
			dto.setImgFileName( dto.getId()+"-"+imgFile.getOriginalFilename() );
		}
		int result = 0;
		try {
			result = mapper.register( dto );
			if( result == 1 ) {
				File file = new File(FilePath.IMAGE_REPO + "/" + dto.getImgFileName() );
				if(imgFile != null ) {
					imgFile.transferTo( file );
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public void delete(String file,String id) {
		try {
			mapper.delete(id);
			File f = new File(FilePath.IMAGE_REPO + "/" + file);
			if( f.exists() ) {
				f.delete();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}











